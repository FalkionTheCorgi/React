export default [
    {id:1, nome: 'Ana', nota:6.2},
    {id:2, nome: 'Bia', nota:7.6},
    {id:3, nome: 'Carlos', nota:8.1},
    {id:4, nome: 'Daniel', nota:5.7},
    {id:5, nome: 'Gui', nota:10.0},
    {id:6, nome: 'Rebeca', nota:9.5},
    {id:7, nome: 'Arthur', nota:7.7},
    {id:8, nome: 'Pedro', nota:6.9},
    {id:9, nome: 'Gustavo', nota:8.8},
]