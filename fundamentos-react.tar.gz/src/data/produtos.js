export default [
    {id:1, nome: 'Sabonete', valor:6.20},
    {id:2, nome: 'Shampoo', valor:5.60},
    {id:3, nome: 'Creme Dental', valor:10.56},
    {id:4, nome: 'Macarrao', valor:20.32},
    {id:5, nome: 'Leite Condensado', valor:2.50},
    {id:6, nome: 'Refrigerante', valor:9.99},
    {id:7, nome: 'Cerveja', valor:7.80},
    {id:8, nome: 'Alface', valor:13.90},
    {id:9, nome: 'Repolho', valor:12.82},
]