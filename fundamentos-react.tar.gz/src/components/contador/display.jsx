import React from 'react'

export default props => {
    return (
        <div>
            <h3>{props.numero}</h3>
        </div>
    )


}