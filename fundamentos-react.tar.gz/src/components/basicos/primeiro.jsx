import React from 'react'

export default function Primeiro(){
    const msg = 'Seja Bem Vindo(A)!'
    return (
        <div>
            <h2>Primeiro Componente</h2>
            <p> {msg} </p>
        </div>
    )
}